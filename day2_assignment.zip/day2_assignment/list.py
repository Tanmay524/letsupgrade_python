#Lists demonstration
color = ["red","white","yellow","green"]
print(color.append("purple"))
print(color.index("green"))
print(color.pop())
print(len(color))