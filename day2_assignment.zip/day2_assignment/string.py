str1="Hi letsupgrade"
str2="it is grate to learn python"
print(str1)
print(str2)
print(str1 +""+ str2)
print(str1[2:8])
print(str2.upper())
print(len(str1))