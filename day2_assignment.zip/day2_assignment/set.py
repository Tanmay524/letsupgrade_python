#Set and its default functions
thisset={"proffessor","tokyo","naiomi"}
print(thisset)
print(thisset.add("requel"))
print(len(thisset))
y=thisset.copy()
print(y)
print(thisset.pop())