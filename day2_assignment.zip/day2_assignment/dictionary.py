# Dictionary and its default functions
dict={
	1:"letsupgrade",
	2:"python",
	'dict2':{
		'name':'thor',
		'weapon':'hammer'
	}
}
print(dict)
print(dict[2])
print(dict['dict2'])
print(dict['dict2']['name'])
print(dict.pop(1))