height= int(input("Hai pilot enter the height :"))
if height <=10000:
	print("now it is safe to land")
elif height >10000 and height <50000:
	print("please bring it to 10000 to land")
else:
	print("Go around and try later")
